# AGENTS.md

Repository: MHaydiNamaza
Authority: `Besmele/`
Mode: BISMILLAH

## PRIMARY RUNTIME RULES
- Highest priority: token economy without lowering engineering quality.
- Answers to questions, status updates, and work summaries must stay within **10 lines max** unless the user explicitly asks for more.
- Keep every response compact, direct, technical, and non-repetitive.
- Work only on explicit scope.
- Do not scan unrelated files.
- Do not broaden tasks without evidence.
- If evidence is missing, say: `NOT ENOUGH EVIDENCE`.

## BISMILLAH BOOTSTRAP
When user says `bismillah`:
1. Read only `Besmele/PROTOKOL.md` and `Besmele/STATE.md`.
2. Read `Besmele/ADR.md` only if the task depends on prior architectural decisions.
3. First line must be: `Bismillah, context loaded, ready to work.`
4. Next line must ask for the target task.

When user says `bismillah kontrol`:
1. Run repository status check.
2. Read `Besmele/STATE.md`.
3. Return a very short repo state summary.
4. Then say: `Context loaded, ready to work.`

## CANONICAL FILES
- Protocol: `Besmele/PROTOKOL.md`
- Active state: `Besmele/STATE.md`
- Task board: `Besmele/WORKBOARD.md`
- Task plans: `Besmele/plans/TASK-xxx.md`
- Delivery log: `Besmele/PUSH_LOG.md`
- Quality gate: `Besmele/QUALITY_GATE.md`
- Architecture decisions: `Besmele/ADR.md`

## EXECUTION RULES
- Analyze before changing.
- Apply the smallest safe patch first.
- Preserve behavior unless change is explicitly intended.
- Avoid speculative refactors.
- Avoid hidden coupling.
- Keep edits atomic and reversible.
- Update only the records directly affected by the task.

## REPO DISCIPLINE
- One independent task -> one `TASK-xxx.md` plan.
- `STATE.md`, `WORKBOARD.md`, and the active `TASK` file must stay consistent.
- `in_progress` tasks are not adopted silently.
- `ProjeOrj/` is archive-only. Do not edit it.
- Do not commit secrets, local machine data, or unnecessary artifacts.
