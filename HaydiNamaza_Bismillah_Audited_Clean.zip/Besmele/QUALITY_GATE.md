# BISMILLAH QUALITY GATE

Check before delivery or push:
- Scope limited to the requested task.
- No unrelated files changed.
- Behavior preserved unless intentionally changed.
- `STATE`, `WORKBOARD`, and active `TASK` are consistent.
- New rule or architecture decision recorded in `ADR` if needed.
- No secrets, local machine data, or unnecessary artifacts included.
- Test or verification status stated honestly.
