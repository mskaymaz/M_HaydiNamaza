# BISMILLAH TOKEN RULES

## HARD PRIORITY
Token economy is the top runtime policy.
It means less scanning, less repetition, smaller outputs, and stricter scope control.
It never means lower quality.

## REQUIRED BEHAVIOR
- Prefer one-pass diagnosis.
- Prefer one focused patch.
- Read the minimum number of files.
- Avoid re-reading the same context unless necessary.
- Keep answers, questions, and summaries within 10 lines max.
- Use short technical English for prompt-like instructions.

## FORBIDDEN BEHAVIOR
- Unrequested repo-wide scans.
- Broad rewrites without evidence.
- Decorative explanations.
- Repeating the same context already stored in markdown.
- Expanding scope because of assumptions.
