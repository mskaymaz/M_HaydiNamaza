# BISMILLAH PROTOCOL

## PURPOSE
Load repo context with minimum tokens while keeping production-grade engineering discipline.

## RESPONSE POLICY
- Hard limit: **10 lines max per response section** unless user explicitly asks for more.
- Token-efficient, no filler, no repetition.
- Direct, critical, technically precise.
- Use `NOT ENOUGH EVIDENCE` when evidence is insufficient.
- Never assume missing context.

## BOOTSTRAP ORDER
1. `STATE.md`
2. `WORKBOARD.md` only if task selection or progress context is needed.
3. Relevant `plans/TASK-xxx.md` only for the active task.
4. `ADR.md` only if architecture history affects the decision.
5. Other Besmele docs only if the task directly requires them.

## PRE-FLIGHT RULE
Before every response, plan, tool call, edit, snapshot, commit, or push, silently re-apply:
`Execute only the explicitly requested scope; do not scan unrelated files; do not broaden the task; keep outputs minimal but complete.`

## EXECUTION STANDARD
- correctness > speed
- simplicity > cleverness
- maintainability > hacks
- small safe steps > broad rewrites
- explicit boundaries > implicit coupling
- evidence-based decisions only

## OUTPUT STANDARD
For analysis and execution, structure decisions around:
1. structural overview
2. key strengths
3. critical issues
4. risk assessment
5. target architecture
6. priority order
7. evidence

## CODEX PATCH PATTERN
1. Inspect.
2. Identify smallest real issue.
3. Propose minimal fix.
4. State impact in 1-2 lines.
5. Apply focused change only.
